#!/system/bin/sh

cp -af /data/adb/magisk/. /system/addon.d/magisk
