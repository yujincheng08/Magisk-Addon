# Magisk-Addon
Keep Magisk installed after OTA under addon.d supported ROMs
